import { useState, useMemo, useEffect } from "react";

const DEFAULT_PROPERTIES = [
  { id: 1, area: "MI", propNumber: "STANSB", name: "STANSBURY PTR", address: "27750 Stansbury", city: "Farmington Hills", state: "MI", zip: "48334", lastInspection: "2025-06-30", sixMonth: "2025-12-30", twelveMonth: "2026-07-01" },
  { id: 2, area: "MI", propNumber: "WARREN", name: "DRP LLC", address: "14517 Eight Mile Road", city: "Warren", state: "MI", zip: "48089", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 3, area: "MI", propNumber: "WTRFRD", name: "DRP, LLC", address: "6680 Highland Road", city: "Waterford", state: "MI", zip: "48327", lastInspection: "2025-11-19", sixMonth: "2026-05-21", twelveMonth: "2026-11-20" },
  { id: 4, area: "MI", propNumber: "DHTS1", name: "DRP LLC", address: "6938 Telegraph Road", city: "Dearborn Heights", state: "MI", zip: "48127", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 5, area: "MI", propNumber: "DHTS2", name: "DRP LLC", address: "6923 Waverly", city: "Dearborn Heights", state: "MI", zip: "48127", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 6, area: "MI", propNumber: "32567", name: "CHRISTOPHER MGMT", address: "32567 Schoolcraft Rd.", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 7, area: "MI", propNumber: "34425", name: "ASHURST LLC", address: "34425 Schoolcraft Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 8, area: "MI", propNumber: "35245", name: "CHRISTOPHER MGMT", address: "35245 Schoolcraft Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 9, area: "MI", propNumber: "35301", name: "CHRISTOPHER MGMT", address: "35301 Schoolcraft Rd.", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 10, area: "MI", propNumber: "35355", name: "CHRISTOPHER MGMT", address: "35355 Schoolcraft Rd.", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 11, area: "MI", propNumber: "35367", name: "CHRISTOPHER MGMT", address: "35367 Schoolcraft Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 12, area: "MI", propNumber: "13455", name: "SGS OWNER LLC", address: "13455 Stamford Ct.", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 13, area: "MI", propNumber: "STMFRD", name: "SGS OWN", address: "13481-13489 Stamford Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 14, area: "MI", propNumber: "13500", name: "ASHURST LLC", address: "13500 Ashurst Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 15, area: "MI", propNumber: "13501", name: "ASHURST LLC", address: "13501 Ashurst Ct.", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-05", sixMonth: "2026-05-07", twelveMonth: "2026-11-06" },
  { id: 16, area: "MI", propNumber: "13550", name: "CHRIS MGMT LTD", address: "13550 Otterson Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 17, area: "MI", propNumber: "13623", name: "CHRIS MGMT LTD", address: "13623 Otterson Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 18, area: "MI", propNumber: "13685", name: "GOS L.L.C.", address: "13685 Otterson Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 19, area: "MI", propNumber: "34450", name: "LIVONIA IND GRP LLC", address: "34450 Industrial Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-07-02", sixMonth: "2026-01-01", twelveMonth: "2026-07-03" },
  { id: 20, area: "MI", propNumber: "35015", name: "DEMBS ROTH MGMT", address: "35015 Glendale", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 21, area: "MI", propNumber: "35255", name: "DEMBS ROTH MGMT", address: "35255 Glendale", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 22, area: "MI", propNumber: "12623", name: "12623 NEWBURGH", address: "12623 Newburgh Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-24", sixMonth: "2026-05-26", twelveMonth: "2026-11-25" },
  { id: 23, area: "MI", propNumber: "AMRHEI", name: "AMRHEIN", address: "37564-37584 Amrhein", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-21", sixMonth: "2026-05-23", twelveMonth: "2026-11-22" },
  { id: 24, area: "MI", propNumber: "37666", name: "NEWBURGH IND GRP", address: "37666 Amrhein Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-24", sixMonth: "2026-05-26", twelveMonth: "2026-11-25" },
  { id: 25, area: "MI", propNumber: "37720", name: "NEWBURGH IND GRP", address: "37720 Amrhein Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 26, area: "MI", propNumber: "37770", name: "RICHFIELD AM", address: "37770 Amrhein Road", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 27, area: "MI", propNumber: "12649", name: "NEWBGH IND GRP", address: "12649 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 28, area: "MI", propNumber: "12665", name: "RICHF PROP GRP", address: "12665 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 29, area: "MI", propNumber: "12671", name: "NEWBGH IND GRP", address: "12671 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 30, area: "MI", propNumber: "12749", name: "NEWBGH IND GRP", address: "12749 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-17", sixMonth: "2026-05-19", twelveMonth: "2026-11-18" },
  { id: 31, area: "MI", propNumber: "12754", name: "RICHF PROP GRP", address: "12754 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-17", sixMonth: "2026-05-19", twelveMonth: "2026-11-18" },
  { id: 32, area: "MI", propNumber: "12866", name: "RICHFIELD AM", address: "12866 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-17", sixMonth: "2026-05-19", twelveMonth: "2026-11-18" },
  { id: 33, area: "MI", propNumber: "12900", name: "RICHFIELD AM", address: "12900 Richfield Court", city: "Livonia", state: "MI", zip: "48150", lastInspection: "2025-11-17", sixMonth: "2026-05-19", twelveMonth: "2026-11-18" },
  { id: 34, area: "MI", propNumber: "40984", name: "D/R GROUP CL", address: "40984 Concept Drive", city: "Plymouth", state: "MI", zip: "48170", lastInspection: "2025-09-09", sixMonth: "2026-03-11", twelveMonth: "2026-09-10" },
  { id: 35, area: "MI", propNumber: "40985", name: "D/R GROUP LTD PTR", address: "40985 Concept Drive", city: "Plymouth", state: "MI", zip: "48110", lastInspection: "2025-11-21", sixMonth: "2026-05-23", twelveMonth: "2026-11-22" },
  { id: 36, area: "MI", propNumber: "44064", name: "PLYMOUTH OAKS", address: "44064 Plymouth Oaks", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-13", sixMonth: "2026-05-15", twelveMonth: "2026-11-14" },
  { id: 37, area: "MI", propNumber: "44160", name: "PLYMOUTH OAKS", address: "44160 Plymouth Oaks Dr.", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-07", sixMonth: "2026-05-09", twelveMonth: "2026-11-08" },
  { id: 38, area: "MI", propNumber: "44176", name: "OAKS 44747", address: "44176-44190 Plymouth Oaks Dr.", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-07", sixMonth: "2026-05-09", twelveMonth: "2026-11-08" },
  { id: 39, area: "MI", propNumber: "44330", name: "OAKS 44747", address: "44330 Plymouth Oaks Blvd.", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-13", sixMonth: "2026-05-15", twelveMonth: "2026-11-14" },
  { id: 40, area: "MI", propNumber: "44747", name: "OAKS 44747", address: "44747 Helm Ct.", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 41, area: "MI", propNumber: "44895", name: "HELM OWNER", address: "44895 Helm Ct.", city: "Plymouth", state: "MI", zip: "48170", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 42, area: "MI", propNumber: "45701", name: "45 MAST", address: "45701 Mast St.", city: "Plymouth", state: "MI", zip: "48170", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 43, area: "MI", propNumber: "45801", name: "45 MAST", address: "45801 Mast St.", city: "Plymouth", state: "MI", zip: "48170", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 44, area: "MI", propNumber: "45889", name: "M G GROUP", address: "45889 Mast St.", city: "Plymouth", state: "MI", zip: "48176", lastInspection: "2025-11-04", sixMonth: "2026-05-06", twelveMonth: "2026-11-05" },
  { id: 45, area: "MI", propNumber: "14900", name: "D/R GRP LTD PTR", address: "14900 Galleon", city: "Plymouth", state: "MI", zip: "48170", lastInspection: "2025-11-06", sixMonth: "2026-05-08", twelveMonth: "2026-11-07" },
  { id: 46, area: "MI", propNumber: "CANTON", name: "4280 HAGGERTY LLC", address: "4280 Haggerty Rd.", city: "Canton", state: "MI", zip: "48188", lastInspection: "2025-11-20", sixMonth: "2026-05-22", twelveMonth: "2026-11-21" },
  { id: 47, area: "MI", propNumber: "2925", name: "JAGAR L.L.C.", address: "2925 Boardwalk", city: "Ann Arbor", state: "MI", zip: "48104", lastInspection: "2025-11-11", sixMonth: "2026-05-13", twelveMonth: "2026-11-12" },
  { id: 48, area: "MI", propNumber: "BOARDW", name: "BOARDWALK LLC", address: "3005 Boardwalk", city: "Ann Arbor", state: "MI", zip: "48108", lastInspection: "2025-09-09", sixMonth: "2026-03-11", twelveMonth: "2026-09-10" },
];

const today = new Date();

function getStatus(dateStr) {
  const date = new Date(dateStr);
  const diffDays = Math.ceil((date - today) / (1000 * 60 * 60 * 24));
  if (diffDays < 0) return { label: "Overdue", color: "#ef4444", bg: "#fef2f2" };
  if (diffDays <= 30) return { label: "Due Soon", color: "#f59e0b", bg: "#fffbeb" };
  return { label: "On Track", color: "#10b981", bg: "#f0fdf4" };
}

function formatDate(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

const STORAGE_KEY = "dembs-roth-property-data";

function loadFromStorage() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return DEFAULT_PROPERTIES;
}

function saveToStorage(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {}
}

export default function App() {
  const [properties, setProperties] = useState(() => loadFromStorage());
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortKey, setSortKey] = useState("id");
  const [sortDir, setSortDir] = useState("asc");
  const [editForm, setEditForm] = useState(null);
  const [saveFlash, setSaveFlash] = useState(false);
  const [view, setView] = useState("table");

  function handleSort(key) {
    if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortKey(key); setSortDir("asc"); }
  }

  function openEdit(p) { setEditForm({ ...p }); }
  function closeEdit() { setEditForm(null); }

  function handleSave() {
    const updated = properties.map(p => p.id === editForm.id ? { ...editForm } : p);
    setProperties(updated);
    saveToStorage(updated);
    setSaveFlash(true);
    setTimeout(() => setSaveFlash(false), 2000);
    closeEdit();
  }

  const filtered = useMemo(() => {
    return properties
      .filter(p => {
        const q = search.toLowerCase();
        const matchSearch = !q || p.name.toLowerCase().includes(q) || p.address.toLowerCase().includes(q) || p.propNumber.toLowerCase().includes(q) || p.city.toLowerCase().includes(q);
        const matchStatus = statusFilter === "All" || getStatus(p.sixMonth).label === statusFilter;
        return matchSearch && matchStatus;
      })
      .sort((a, b) => {
        let val;
        if (sortKey === "city") val = a.city.localeCompare(b.city);
        else if (sortKey === "name") val = a.name.localeCompare(b.name);
        else if (sortKey === "propNumber") val = a.propNumber.localeCompare(b.propNumber);
        else if (sortKey === "address") val = a.address.localeCompare(b.address);
        else if (sortKey === "lastInspection") val = new Date(a.lastInspection) - new Date(b.lastInspection);
        else if (sortKey === "sixMonth") val = new Date(a.sixMonth) - new Date(b.sixMonth);
        else if (sortKey === "twelveMonth") val = new Date(a.twelveMonth) - new Date(b.twelveMonth);
        else if (sortKey === "status") val = getStatus(a.sixMonth).label.localeCompare(getStatus(b.sixMonth).label);
        else val = a.id - b.id;
        return sortDir === "asc" ? val : -val;
      });
  }, [properties, search, statusFilter, sortKey, sortDir]);

  const stats = useMemo(() => ({
    total: properties.length,
    onTrack: properties.filter(p => getStatus(p.sixMonth).label === "On Track").length,
    dueSoon: properties.filter(p => getStatus(p.sixMonth).label === "Due Soon").length,
    overdue: properties.filter(p => getStatus(p.sixMonth).label === "Overdue").length,
  }), [properties]);

  const inputStyle = { width: "100%", padding: "8px 10px", border: "1.5px solid #d0d5e8", borderRadius: 7, fontSize: 13, fontFamily: "'Source Sans 3', sans-serif", background: "#f9faff", outline: "none" };
  const labelStyle = { fontSize: 11, color: "#555", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.6px", marginBottom: 5, display: "block", fontFamily: "'Source Sans 3', sans-serif" };

  return (
    <div style={{ fontFamily: "'Georgia', serif", minHeight: "100vh", background: "#f8f7f4", color: "#1a1a2e" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Source+Sans+3:wght@400;500;600&display=swap');
        * { box-sizing: border-box; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
        .row-hover:hover { background: #f0f4ff !important; cursor: pointer; }
        .edit-btn-cell { opacity: 0; transition: opacity 0.15s; }
        tr:hover .edit-btn-cell { opacity: 1; }
        .prop-card { transition: all 0.2s; cursor: pointer; }
        .prop-card:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.12); }
        input, select { outline: none; font-family: 'Source Sans 3', sans-serif; }
        .tab-active { background: white; color: #1a1a2e; }
        .tab-inactive { background: transparent; color: rgba(255,255,255,0.6); border: 1px solid rgba(255,255,255,0.25); }
        .tab-btn { padding: 7px 18px; border-radius: 8px; border: none; cursor: pointer; font-size: 13px; font-family: 'Source Sans 3', sans-serif; font-weight: 600; transition: all 0.15s; }
        .header-flash { animation: flashGreen 2s ease forwards; }
        @keyframes flashGreen { 0%,100%{background:#1a1a2e} 30%,70%{background:#065f46} }
        .field-input:focus { border-color: #4f46e5 !important; box-shadow: 0 0 0 3px rgba(79,70,229,0.12) !important; }
        .overlay { position: fixed; inset: 0; background: rgba(10,10,30,0.55); z-index: 200; display: flex; align-items: center; justify-content: center; padding: 20px; backdrop-filter: blur(2px); }
        .modal { background: white; border-radius: 16px; width: 100%; max-width: 640px; box-shadow: 0 24px 80px rgba(0,0,0,0.3); overflow: hidden; animation: modalIn 0.2s ease; }
        @keyframes modalIn { from { transform: translateY(16px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .save-btn:hover { background: #4338ca !important; }
        .cancel-btn:hover { background: #f5f5f5 !important; }
      `}</style>

      {/* Header */}
      <div className={saveFlash ? "header-flash" : ""} style={{ background: "#1a1a2e", color: "white", padding: "28px 32px 24px" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
            <div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, fontWeight: 700, letterSpacing: "-0.5px" }}>
                Dembs Roth Property Management Inspections
                {saveFlash && <span style={{ marginLeft: 12, fontSize: 14, background: "#10b981", padding: "2px 12px", borderRadius: 20, fontFamily: "'Source Sans 3', sans-serif", fontWeight: 600, verticalAlign: "middle" }}>✓ Saved</span>}
              </div>
              <div style={{ color: "#8892b0", fontSize: 13, marginTop: 4, fontFamily: "'Source Sans 3', sans-serif" }}>
                Michigan Portfolio · {properties.length} Properties
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className={`tab-btn ${view === "table" ? "tab-active" : "tab-inactive"}`} onClick={() => setView("table")}>⊞ Table</button>
              <button className={`tab-btn ${view === "cards" ? "tab-active" : "tab-inactive"}`} onClick={() => setView("cards")}>⊟ Cards</button>
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: "flex", gap: 16, marginTop: 24, flexWrap: "wrap" }}>
            {[
              { label: "Total Properties", val: stats.total, color: "#64748b", icon: "🏢", filter: "All" },
              { label: "On Track", val: stats.onTrack, color: "#10b981", icon: "✅", filter: "On Track" },
              { label: "Due Soon", val: stats.dueSoon, color: "#f59e0b", icon: "⚠️", filter: "Due Soon" },
              { label: "Overdue", val: stats.overdue, color: "#ef4444", icon: "🚨", filter: "Overdue" },
            ].map(s => {
              const isActive = statusFilter === s.filter;
              return (
                <div key={s.label} onClick={() => setStatusFilter(isActive && s.filter !== "All" ? "All" : s.filter)}
                  style={{ background: isActive ? "rgba(255,255,255,0.18)" : "rgba(255,255,255,0.07)", borderRadius: 10, padding: "12px 20px", minWidth: 130, border: isActive ? `2px solid ${s.color}` : "1px solid rgba(255,255,255,0.1)", cursor: "pointer", transition: "all 0.15s", transform: isActive ? "translateY(-2px)" : "none", boxShadow: isActive ? `0 4px 16px ${s.color}44` : "none" }}>
                  <div style={{ fontSize: 22, marginBottom: 2 }}>{s.icon}</div>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 26, fontWeight: 700, color: s.color }}>{s.val}</div>
                  <div style={{ fontSize: 12, color: "#8892b0", fontFamily: "'Source Sans 3', sans-serif" }}>{s.label}</div>
                  <div style={{ fontSize: 10, color: isActive ? s.color : "rgba(255,255,255,0.3)", marginTop: 4, fontFamily: "'Source Sans 3', sans-serif", fontWeight: 600 }}>{isActive && s.filter !== "All" ? "✕ Clear filter" : "Click to filter"}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 32px" }}>
        <div className="card" style={{ padding: "16px 20px", marginBottom: 20, display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍  Search name, address, or code..."
            style={{ flex: 1, minWidth: 200, padding: "9px 14px", border: "1.5px solid #e0e0e0", borderRadius: 8, fontSize: 14, background: "#f9f9f9" }} />
          <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 13, color: "#666" }}>{filtered.length} result{filtered.length !== 1 ? "s" : ""}</div>
          <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 12, color: "#aaa" }}>✏️ Click any row to edit</div>
        </div>

        {view === "table" && (
          <div className="card" style={{ overflow: "hidden" }}>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "'Source Sans 3', sans-serif", fontSize: 14 }}>
                <thead>
                  <tr style={{ background: "#f0f2f8", borderBottom: "2px solid #e0e4f0" }}>
                    {[
                      { label: "#", key: "id" }, { label: "Prop Code", key: "propNumber" },
                      { label: "Property Name", key: "name" }, { label: "Address", key: "address" },
                      { label: "City", key: "city" }, { label: "Last Inspection", key: "lastInspection" },
                      { label: "6-Month Due", key: "sixMonth" }, { label: "12-Month Due", key: "twelveMonth" },
                      { label: "Status", key: "status" }, { label: "", key: null },
                    ].map(({ label, key }) => {
                      if (!key) return <th key="act" style={{ padding: "12px 12px", width: 70 }} />;
                      const isActive = sortKey === key;
                      return (
                        <th key={key} onClick={() => handleSort(key)}
                          style={{ padding: "12px 16px", textAlign: "left", fontWeight: 600, fontSize: 12, color: isActive ? "#4f46e5" : "#444", letterSpacing: "0.5px", textTransform: "uppercase", whiteSpace: "nowrap", cursor: "pointer", userSelect: "none", background: isActive ? "#e8ecfb" : undefined }}>
                          {label}<span style={{ opacity: isActive ? 1 : 0.35, fontSize: 10, marginLeft: 3 }}>{isActive ? (sortDir === "asc" ? "▲" : "▼") : "⇅"}</span>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p, i) => {
                    const s = getStatus(p.sixMonth);
                    return (
                      <tr key={p.id} className="row-hover"
                        style={{ borderBottom: "1px solid #f0f0f0", background: i % 2 === 0 ? "white" : "#fafafa" }}
                        onClick={() => openEdit(p)}>
                        <td style={{ padding: "11px 16px", color: "#bbb", fontWeight: 600 }}>{p.id}</td>
                        <td style={{ padding: "11px 16px", fontWeight: 600, color: "#334", fontFamily: "monospace", fontSize: 13 }}>{p.propNumber}</td>
                        <td style={{ padding: "11px 16px", fontWeight: 500 }}>{p.name}</td>
                        <td style={{ padding: "11px 16px", color: "#555" }}>{p.address}</td>
                        <td style={{ padding: "11px 16px", color: "#555" }}>{p.city}</td>
                        <td style={{ padding: "11px 16px", color: "#555", whiteSpace: "nowrap" }}>{formatDate(p.lastInspection)}</td>
                        <td style={{ padding: "11px 16px", whiteSpace: "nowrap" }}>{formatDate(p.sixMonth)}</td>
                        <td style={{ padding: "11px 16px", whiteSpace: "nowrap" }}>{formatDate(p.twelveMonth)}</td>
                        <td style={{ padding: "11px 16px" }}>
                          <span style={{ background: s.bg, color: s.color, border: `1px solid ${s.color}30`, padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>● {s.label}</span>
                        </td>
                        <td style={{ padding: "11px 12px" }}>
                          <span className="edit-btn-cell" style={{ background: "#eff0ff", color: "#4f46e5", border: "1px solid #c7d2fe", padding: "4px 11px", borderRadius: 6, fontSize: 12, fontWeight: 600 }}>✏️ Edit</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filtered.length === 0 && <div style={{ padding: 40, textAlign: "center", color: "#999" }}>No properties match your filters.</div>}
            </div>
          </div>
        )}

        {view === "cards" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
            {filtered.map(p => {
              const s = getStatus(p.sixMonth);
              return (
                <div key={p.id} className="card prop-card" style={{ padding: "18px 20px", border: "2px solid transparent" }} onClick={() => openEdit(p)}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div>
                      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 15, fontWeight: 600, color: "#1a1a2e" }}>{p.name}</div>
                      <div style={{ fontFamily: "monospace", fontSize: 11, color: "#888", marginTop: 2 }}>{p.propNumber}</div>
                    </div>
                    <span style={{ background: s.bg, color: s.color, border: `1px solid ${s.color}30`, padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>{s.label}</span>
                  </div>
                  <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 13, color: "#555", marginBottom: 12 }}>
                    <div>📍 {p.address}</div>
                    <div style={{ color: "#888", marginTop: 2 }}>{p.city}, {p.state} {p.zip}</div>
                  </div>
                  <div style={{ borderTop: "1px solid #f0f0f0", paddingTop: 10, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                    {[["Last", p.lastInspection], ["6-Mo", p.sixMonth], ["12-Mo", p.twelveMonth]].map(([label, d]) => (
                      <div key={label} style={{ background: "#f8f8f8", borderRadius: 6, padding: "6px 8px" }}>
                        <div style={{ fontSize: 10, color: "#999", fontWeight: 600, marginBottom: 2, fontFamily: "'Source Sans 3', sans-serif" }}>{label}</div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "#333", fontFamily: "'Source Sans 3', sans-serif" }}>{formatDate(d)}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ marginTop: 10, textAlign: "right" }}>
                    <span style={{ fontSize: 11, color: "#4f46e5", fontFamily: "'Source Sans 3', sans-serif", fontWeight: 600 }}>✏️ Click to edit</span>
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && <div style={{ gridColumn: "1/-1", padding: 40, textAlign: "center", color: "#999" }}>No properties match your filters.</div>}
          </div>
        )}
      </div>

      {editForm && (
        <div className="overlay" onClick={closeEdit}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ background: "#1a1a2e", padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 19, fontWeight: 700, color: "white" }}>Edit Property</div>
                <div style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 12, color: "#8892b0", marginTop: 3 }}>#{editForm.id} · {editForm.propNumber} · Changes saved to your browser</div>
              </div>
              <button onClick={closeEdit} style={{ background: "rgba(255,255,255,0.1)", border: "none", color: "white", width: 34, height: 34, borderRadius: 8, cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
            </div>

            <div style={{ padding: "22px 24px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px 20px", maxHeight: "60vh", overflowY: "auto" }}>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={labelStyle}>Property Name</label>
                <input className="field-input" type="text" value={editForm.name} onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Property Code</label>
                <input className="field-input" type="text" value={editForm.propNumber} onChange={e => setEditForm(f => ({ ...f, propNumber: e.target.value }))} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Area</label>
                <input className="field-input" type="text" value={editForm.area} onChange={e => setEditForm(f => ({ ...f, area: e.target.value }))} style={inputStyle} />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={labelStyle}>Address</label>
                <input className="field-input" type="text" value={editForm.address} onChange={e => setEditForm(f => ({ ...f, address: e.target.value }))} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>City</label>
                <input className="field-input" type="text" value={editForm.city} onChange={e => setEditForm(f => ({ ...f, city: e.target.value }))} style={inputStyle} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <label style={labelStyle}>State</label>
                  <input className="field-input" type="text" value={editForm.state} onChange={e => setEditForm(f => ({ ...f, state: e.target.value }))} style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>ZIP</label>
                  <input className="field-input" type="text" value={editForm.zip} onChange={e => setEditForm(f => ({ ...f, zip: e.target.value }))} style={inputStyle} />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Last Inspection Date</label>
                <input className="field-input" type="date" value={editForm.lastInspection} onChange={e => setEditForm(f => ({ ...f, lastInspection: e.target.value }))} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>6-Month Due Date</label>
                <input className="field-input" type="date" value={editForm.sixMonth} onChange={e => setEditForm(f => ({ ...f, sixMonth: e.target.value }))} style={inputStyle} />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={labelStyle}>12-Month Due Date</label>
                <input className="field-input" type="date" value={editForm.twelveMonth} onChange={e => setEditForm(f => ({ ...f, twelveMonth: e.target.value }))} style={inputStyle} />
              </div>
              <div style={{ gridColumn: "1 / -1", background: "#f5f6ff", borderRadius: 10, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, border: "1px solid #e0e4f8" }}>
                <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 11, color: "#666", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.5px" }}>Status Preview:</span>
                {(() => { const s = getStatus(editForm.sixMonth); return <span style={{ background: s.bg, color: s.color, border: `1px solid ${s.color}40`, padding: "4px 14px", borderRadius: 20, fontSize: 13, fontWeight: 700 }}>● {s.label}</span>; })()}
                <span style={{ fontFamily: "'Source Sans 3', sans-serif", fontSize: 11, color: "#aaa" }}>updates based on 6-month date</span>
              </div>
            </div>

            <div style={{ padding: "16px 24px", borderTop: "1px solid #eee", display: "flex", justifyContent: "flex-end", gap: 10, background: "#fafafa" }}>
              <button className="cancel-btn" onClick={closeEdit}
                style={{ padding: "9px 22px", borderRadius: 8, border: "1.5px solid #e0e0e0", background: "white", color: "#555", cursor: "pointer", fontFamily: "'Source Sans 3', sans-serif", fontSize: 14, fontWeight: 600, transition: "background 0.15s" }}>
                Cancel
              </button>
              <button className="save-btn" onClick={handleSave}
                style={{ padding: "9px 26px", borderRadius: 8, border: "none", background: "#4f46e5", color: "white", cursor: "pointer", fontFamily: "'Source Sans 3', sans-serif", fontSize: 14, fontWeight: 600, boxShadow: "0 2px 10px rgba(79,70,229,0.35)", transition: "background 0.15s" }}>
                💾 Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
