# Dembs Roth Property Management Inspections

A property inspection tracking dashboard built with React + Vite.

## Deploying to Vercel

### Step 1 — Upload to GitHub
1. Go to [github.com](https://github.com) and sign in (or create a free account)
2. Click the green **"New"** button to create a new repository
3. Name it `dembs-roth-inspections`, set it to **Public**, check **"Add a README file"**, click **"Create repository"**
4. Click **"Add file"** → **"Upload files"**
5. Upload ALL the files from this folder (keeping the folder structure intact)
6. Click **"Commit changes"**

### Step 2 — Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign up with your GitHub account
2. Click **"Add New Project"**
3. Select the `dembs-roth-inspections` repository
4. Leave all settings as default — Vercel will auto-detect it as a Vite project
5. Click **"Deploy"**
6. In ~2 minutes you'll have a live link like `dembs-roth-inspections.vercel.app`

### Updating the site later
Any time you want to make changes, update the files on GitHub and Vercel will automatically redeploy.
